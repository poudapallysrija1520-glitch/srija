# Kickoff Planner

An AI project-management assistant for people with no project-management knowledge.
The client describes what they need in everyday words ("I want to open a small bakery before the summer with €60,000")
and gets a complete, tailored plan:

- **Gantt chart and timeline**: every task on a calendar, with dependency arrows, milestones and the **critical path** highlighted. Zoom by days, weeks or months; download as PNG.
- **Tasks, deadlines, dependencies and milestones**: dates are calculated by the app over working days (Mon–Fri) using the critical path method, so they are always consistent. Edit durations, owners or dependencies and everything updates.
- **Six Word documents** (.docx), built from the current plan:
  1. Project Charter *(core)*
  2. Project Management Plan, with WBS, Gantt image, schedule, resources, budget, quality and change control *(core)*
  3. Risk Register & Communication Plan, with a risk heat map and escalation path *(core)*
  4. Stakeholder Register & RACI Matrix
  5. Status Report #1
  6. Project Closure & Lessons Learned
- **Reports and exports**: tasks as CSV (Excel / MS Project import), Gantt PNG, and everything in one .zip.
- **Plain-language changes**: "Finish by June", "We only have 2 people", "Add a website". The AI updates the whole plan.

Plans are saved in the browser, so people can come back to them.

---

## Deploy on Vercel (about 5 minutes)

You need a free [GitHub](https://github.com) account, a free [Vercel](https://vercel.com) account, and an
Anthropic API key from [console.anthropic.com](https://console.anthropic.com). API usage is billed separately from a Claude subscription.

1. **Put the code on GitHub.** Create a new repository and upload this folder's contents.
   (On github.com: *New repository* → *uploading an existing file* → drag in all files and folders → *Commit*.)
   Don't upload a `.env` or `.env.local` file.
2. **Import it in Vercel.** On vercel.com click **Add New… → Project**, choose your repository, and click **Import**.
   Vercel detects Next.js automatically, so leave the build settings as they are.
3. **Add your key.** Before clicking Deploy, open **Environment Variables** and add:
   | Name | Value |
   |---|---|
   | `ANTHROPIC_API_KEY` | your key, `sk-ant-...` (required) |
   | `ACCESS_CODE` | a password of your choice (recommended; see below) |
4. Click **Deploy**. After a minute you get a public link like `https://kickoff-planner.vercel.app` that works in Chrome, Safari, Edge and Firefox, on laptops and phones.

To change a variable later: Project → **Settings → Environment Variables**, then **Deployments → ⋯ → Redeploy**.

### Protect your API key credit
Anyone with the link can generate plans, and every plan costs a few cents of API usage.
Set `ACCESS_CODE` and only people you give the code to can generate plans (the example plan and the documents still work for everyone).
The app asks for the code the first time and remembers it in that browser.

### Timeouts
Generating a plan usually takes 30–90 seconds. The API route sets `maxDuration = 300` seconds, which Vercel allows with
Fluid Compute (on by default for new projects). If your plan limits functions to less, lower `maxDuration` in
`app/api/plan/route.js`. If plans fail after exactly 60 seconds, that limit is the reason.

---

## Run on your computer (VS Code)

1. Install [Node.js](https://nodejs.org) (LTS version) and open this folder in VS Code (**File → Open Folder…**).
2. Open a terminal (**Terminal → New Terminal**) and install the packages:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env.local` and paste your `ANTHROPIC_API_KEY`.
4. Start it:
   ```bash
   npm run dev
   ```
5. Open **http://localhost:3000**.

---

## Settings

| Variable | Required | What it does |
|---|---|---|
| `ANTHROPIC_API_KEY` | yes | Lets the server ask Claude to write plans. Never sent to the browser. |
| `ACCESS_CODE` | no | If set, a code is needed to generate plans. |
| `ANTHROPIC_MODEL` | no | Model that writes the plans. Default `claude-sonnet-5-5`. |

## How it works

```
Browser (lib/app.js)                          Server (app/api/plan/route.js)
  plain-language request  ── POST /api/plan ──▶  Claude, forced to call a tool whose
                                                 input schema is lib/plan-schema.js
  progress (tasks drafted) ◀── NDJSON stream ──  {"progress": n} ... {"plan": {...}}
  normalizePlan() + schedulePlan()  (lib/schedule.js: cleans the data, breaks dependency loops,
                                     works out dates over working days, critical path, budget)
  Gantt (lib/gantt.js), Word documents (lib/docs.js with the docx package), CSV / PNG / zip
```

The AI only proposes *what* needs doing, how long each task takes, and what depends on what.
Every date, the end date and the critical path are calculated in code, so the Gantt chart, task table and documents always agree.

## Project structure

```
app/
  layout.js            page shell, fonts, styles
  page.js              mounts the app in the browser
  api/plan/route.js    calls Claude and streams the plan back
lib/
  app.js               the whole interface (framework-free)
  plan-schema.js       the plan structure + the instructions given to the AI
  schedule.js          validation, working-day scheduling, critical path, CSV
  gantt.js             interactive Gantt + image for documents
  docs.js              the six Word documents
  sample-plan.js       the built-in example plan
  host-web.js          browser ↔ server glue for this site
  host-claude.js       glue for the Claude-hosted demo
  styles.css           design tokens, light and dark themes
scripts/
  build-artifact.py    bundles lib/ into one HTML page for the Claude demo
```

## Good to know

- Plans are estimates. Check durations and costs with the people doing the work, then edit them on the Tasks tab.
- The AI writes in the same language the client uses. Document headings are in English.
- Plans are stored in the browser (localStorage), not on the server. Clearing browser data removes them; download the documents to keep a copy.
