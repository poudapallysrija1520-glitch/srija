"""Bundle lib/*.js + styles into one self-contained HTML page for the Claude demo.

Usage: python scripts/build-artifact.py OUT.html [--test]
--test swaps in a host that downloads with <a download> and fakes the AI, for local browser checks.
"""
import re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
LIB = ROOT / "lib"
ORDER = ["schedule.js", "plan-schema.js", "sample-plan.js", "gantt.js", "docs.js", "app.js", "host-claude.js"]

def strip_module(src: str) -> str:
    src = re.sub(r'^\s*import\s[^;]*?from\s+"[^"]+";\s*$', "", src, flags=re.M)
    src = re.sub(r'^export\s+(?=(async\s+)?(function|const|let|class)\b)', "", src, flags=re.M)
    return src

out = pathlib.Path(sys.argv[1])
test = "--test" in sys.argv
def as_module(name: str) -> str:
    src = (LIB / name).read_text(encoding="utf-8")
    names = re.findall(r'^export\s+(?:async\s+)?(?:function|const|let|class)\s+([A-Za-z_$][\w$]*)', src, flags=re.M)
    var = "__m_" + re.sub(r"\W", "_", name)
    return (f"// ---- {name}\nconst {var} = (() => {{\n{strip_module(src)}\nreturn {{ {', '.join(names)} }};\n}})();\n"
            f"const {{ {', '.join(names)} }} = {var};\n")

js = "\n".join(as_module(f) for f in ORDER)
css = (LIB / "styles.css").read_text(encoding="utf-8")
test_host = """
const host = {
  ...claudeHost,
  async generatePlan(args, { signal, onProgress }) {
    for (let i = 1; i <= 5; i++) { await new Promise((r) => setTimeout(r, 120)); if (signal.aborted) { const a = new Error("x"); a.name = "AbortError"; throw a; } onProgress(i * 4); }
    const p = JSON.parse(JSON.stringify(SAMPLE_PLAN)); p.project_name = "Test: " + (args.change ? "updated" : "generated") + " plan"; return p;
  },
  async saveFile(name, blob) { window.__saved = window.__saved || []; window.__saved.push({ name, size: blob.size }); const u = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); },
};""" if test else "const host = claudeHost;"

html = f"""<title>Kickoff Planner</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@75..100,500..800&family=Source+Sans+3:wght@400;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<style>
{css}
html, body {{ height: auto; }}
</style>
<div id="app"></div>
<script src="https://cdn.jsdelivr.net/npm/docx@9.8.1/dist/index.iife.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script>
(() => {{
{js}
{test_host}
mountApp(document.getElementById("app"), host);
}})();
</script>
"""
out.write_text(html, encoding="utf-8")
print("wrote", out, len(html), "bytes")
