// POST /api/plan — turns the client's request into a structured plan with Claude.
// The response streams NDJSON: {"progress": n} lines while tasks are drafted, then {"plan": {...}} or {"error": "..."}.
import Anthropic from "@anthropic-ai/sdk";
import { PLAN_SCHEMA, buildPlanPrompt } from "../../../lib/plan-schema.js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300; // seconds; lower it if your Vercel plan allows less

const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";

const json = (body, status = 200) => Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
const text = (v, max) => (typeof v === "string" ? v.trim().slice(0, max) : "");

function friendly(e) {
  const s = e && e.status;
  if (s === 401) return { error: "The server's Anthropic API key was rejected. Check ANTHROPIC_API_KEY in your environment variables.", code: "bad_key" };
  if (s === 404) return { error: "The AI model " + MODEL + " isn't available to this API key. Set ANTHROPIC_MODEL to another model.", code: "model" };
  if (s === 429) return { error: "Too many requests right now. Wait a minute and try again.", code: "rate_limited" };
  if (s === 529 || s === 503) return { error: "The AI service is busy. Please try again in a moment.", code: "busy" };
  if (e && e.name === "AbortError") return { error: "Cancelled.", code: "cancelled" };
  return { error: "The plan couldn't be generated. Please try again.", code: "server" };
}

export async function POST(req) {
  let body;
  try { body = await req.json(); } catch { return json({ error: "The request was not valid JSON." }, 400); }

  if (!process.env.ANTHROPIC_API_KEY) {
    return json({ error: "This site has no AI key yet. Add ANTHROPIC_API_KEY in Vercel → Project → Settings → Environment Variables (or in .env.local), then redeploy.", code: "no_key" }, 500);
  }
  const need = process.env.ACCESS_CODE;
  if (need && body.accessCode !== need) {
    return json({ error: "This site is protected. Enter the access code you were given.", code: "access_code" }, 401);
  }

  const change = text(body.change, 1500) || null;
  const request = text(body.request, 4000);
  if (!change && request.length < 12) return json({ error: "Describe the project in a sentence or two." }, 400);
  const d = body.details && typeof body.details === "object" ? body.details : {};
  const details = { startDate: text(d.startDate, 10), deadline: text(d.deadline, 10), budget: text(d.budget, 120), team: text(d.team, 300) };
  const today = /^\d{4}-\d{2}-\d{2}$/.test(body.today || "") ? body.today : new Date().toISOString().slice(0, 10);
  const prompt = buildPlanPrompt({ request, details, today, currentPlan: change ? body.currentPlan : null, change });
  if (prompt.length > 180000) return json({ error: "The plan is too large to update in one go. Start a new project instead." }, 413);

  const client = new Anthropic();
  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (o) => { try { controller.enqueue(enc.encode(JSON.stringify(o) + "\n")); } catch {} };
      let last = -1;
      try {
        const s = client.messages.stream({
          model: MODEL,
          max_tokens: 16000,
          tools: [{ name: "save_project_plan", description: "Save the complete, tailored project plan.", input_schema: PLAN_SCHEMA }],
          tool_choice: { type: "tool", name: "save_project_plan" },
          messages: [{ role: "user", content: prompt }],
        }, { signal: req.signal });
        s.on("inputJson", (_delta, snapshot) => {
          const n = snapshot && Array.isArray(snapshot.tasks) ? snapshot.tasks.length : 0;
          if (n !== last) { last = n; send({ progress: n }); }
        });
        const msg = await s.finalMessage();
        const tool = msg.content.find((b) => b.type === "tool_use");
        if (!tool || !tool.input || typeof tool.input !== "object") throw new Error("No plan in the reply");
        send({ plan: tool.input, truncated: msg.stop_reason === "max_tokens" });
      } catch (e) {
        console.error("plan generation failed:", e && (e.status || ""), e && e.message);
        send(friendly(e));
      }
      try { controller.close(); } catch {}
    },
  });
  return new Response(stream, {
    headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store", "X-Accel-Buffering": "no" },
  });
}
