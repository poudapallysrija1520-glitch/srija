"use client";

import { useEffect, useRef } from "react";

export default function Home() {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || el.dataset.mounted) return; // React dev mode runs effects twice
    el.dataset.mounted = "1";
    Promise.all([import("../lib/app.js"), import("../lib/host-web.js")]).then(([{ mountApp }, { webHost }]) => {
      mountApp(el, webHost);
    });
  }, []);

  return <div ref={ref} style={{ minHeight: "100vh" }} />;
}
